#pragma once
#include "Objeto.h"
class NoDest :
	public Objeto
{
public:
	NoDest( int, int );
	~NoDest();
};

