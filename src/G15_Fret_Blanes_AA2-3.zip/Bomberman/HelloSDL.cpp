/*#include <SDL.h>
#include <exception>
#include <iostream>
#include <string>

#include "Game.h"


int main(int argc, char *argv[]) {

	Game a;
	std::cout << a.Estado;

	return 0;
}*/